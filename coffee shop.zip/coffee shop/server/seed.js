const db = require("./db");

const menu = [
    {
        name: "Cappuccino",
        category: "hot",
        label: "Hot",
        description: "Rich espresso topped with silky milk foam.",
        price: 180,
        badge: "Popular",
        image: "https://images.unsplash.com/photo-1572449043416-55f4685c9bb7?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Espresso",
        category: "espresso",
        label: "Hot",
        description: "Bold, rich and intense with a smooth finish.",
        price: 140,
        image: "https://images.unsplash.com/photo-1510707577719-ae7c14805e3a?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Latte",
        category: "hot",
        label: "Hot",
        description: "Smooth espresso blended with steamed milk.",
        price: 190,
        badge: "Popular",
        image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Mocha",
        category: "hot",
        label: "Hot",
        description: "Espresso, chocolate and steamed creamy milk.",
        price: 220,
        image: "https://images.unsplash.com/photo-1542990253-0d0f5be5f0ed?auto=format&fit=crop&w=700&q=80",
        infoImage: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Americano",
        category: "hot",
        label: "Hot",
        description: "Espresso combined with hot water for a clean taste.",
        price: 160,
        image: "https://images.unsplash.com/photo-1498804103079-a6351b050096?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Cold Coffee",
        category: "cold",
        label: "Cold",
        description: "Chilled coffee blended with creamy milk and ice.",
        price: 210,
        image: "https://images.unsplash.com/photo-1517701550927-30cf4ba1dba5?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Caramel Macchiato",
        category: "special",
        label: "Special",
        description: "Espresso, vanilla, milk and caramel drizzle.",
        price: 240,
        badge: "Chef's choice",
        image: "https://images.unsplash.com/photo-1485808191679-5f86510681a2?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Chocolate Frappe",
        category: "cold",
        label: "Cold",
        description: "Ice-blended chocolate coffee with whipped cream.",
        price: 250,
        image: "https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Masala Chai",
        category: "tea",
        label: "Tea",
        description: "Fragrant black tea simmered with warming spices.",
        price: 120,
        image: "https://images.unsplash.com/photo-1544787219-7f47ccb76574?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Butter Croissant",
        category: "dessert",
        label: "Dessert",
        description: "A flaky, golden pastry baked fresh each morning.",
        price: 150,
        badge: "Fresh today",
        image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=700&q=80"
    },
    {
        name: "Cinnamon Toast",
        category: "snack",
        label: "Snack",
        description: "Griddled sourdough with cinnamon butter and honey.",
        price: 160,
        image: "https://images.unsplash.com/photo-1484723091739-30a097e8f929?auto=format&fit=crop&w=700&q=80"
    }
];

const insert = db.prepare(`
    INSERT INTO products (name, category, label, description, price, badge, image, info_image)
    VALUES (@name, @category, @label, @description, @price, @badge, @image, @infoImage)
    ON CONFLICT(name) DO UPDATE SET
        category = excluded.category,
        label = excluded.label,
        description = excluded.description,
        price = excluded.price,
        badge = excluded.badge,
        image = excluded.image,
        info_image = excluded.info_image
`);

const seed = db.transaction(items => {
    items.forEach(item => insert.run({ badge: null, infoImage: null, ...item }));
});

seed(menu);

const total = db.prepare("SELECT COUNT(*) AS n FROM products").get().n;
console.log(`Seed complete. ${total} products in the database.`);
