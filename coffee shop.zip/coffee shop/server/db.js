const path = require("path");
const Database = require("better-sqlite3");

const dbPath = process.env.DB_PATH || path.join(__dirname, "coffee.db");
const db = new Database(dbPath);

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS products (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL UNIQUE,
    category    TEXT    NOT NULL,
    label       TEXT    NOT NULL,
    description TEXT    NOT NULL,
    price       INTEGER NOT NULL,
    badge       TEXT,
    image       TEXT    NOT NULL,
    info_image  TEXT
);

CREATE TABLE IF NOT EXISTS orders (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    order_number   TEXT    NOT NULL UNIQUE,
    customer_name  TEXT    NOT NULL,
    phone          TEXT    NOT NULL,
    fulfillment    TEXT    NOT NULL CHECK (fulfillment IN ('pickup', 'delivery')),
    address        TEXT,
    total          INTEGER NOT NULL,
    status         TEXT    NOT NULL DEFAULT 'received',
    created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS order_items (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id      INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_name  TEXT    NOT NULL,
    price         INTEGER NOT NULL,
    quantity      INTEGER NOT NULL,
    size          TEXT,
    milk          TEXT,
    extra_shot    INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS reservations (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    phone       TEXT    NOT NULL,
    date        TEXT    NOT NULL,
    time        TEXT    NOT NULL,
    guests      INTEGER NOT NULL,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT    NOT NULL,
    email       TEXT    NOT NULL,
    message     TEXT    NOT NULL,
    created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);
`);

const productColumns = db.prepare("PRAGMA table_info(products)").all().map(column => column.name);
if (!productColumns.includes("info_image")) {
    db.exec("ALTER TABLE products ADD COLUMN info_image TEXT");
}

module.exports = db;
