const path = require("path");
const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use(express.static(path.join(__dirname, "..")));

function asString(value) {
    return typeof value === "string" ? value.trim() : "";
}

function isPhone(value) {
    return /^[0-9+() -]{10,}$/.test(value);
}

function isEmail(value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

app.get("/api/health", (req, res) => {
    res.json({ ok: true });
});

app.get("/api/products", (req, res) => {
    const { category } = req.query;
    const columns = "id, name, category, label, description, price, badge, image, info_image AS infoImage";

    const products = category && category !== "all"
        ? db.prepare(`SELECT ${columns} FROM products WHERE category = ? ORDER BY id`).all(category)
        : db.prepare(`SELECT ${columns} FROM products ORDER BY id`).all();

    res.json(products);
});

app.get("/api/products/:id", (req, res) => {
    const product = db.prepare("SELECT id, name, category, label, description, price, badge, image, info_image AS infoImage FROM products WHERE id = ?").get(req.params.id);

    if (!product) {
        return res.status(404).json({ error: "Product not found." });
    }

    res.json(product);
});

const insertOrder = db.prepare(`
    INSERT INTO orders (order_number, customer_name, phone, fulfillment, address, total)
    VALUES (@orderNumber, @customerName, @phone, @fulfillment, @address, @total)
`);

const insertOrderItem = db.prepare(`
    INSERT INTO order_items (order_id, product_name, price, quantity, size, milk, extra_shot)
    VALUES (@orderId, @productName, @price, @quantity, @size, @milk, @extraShot)
`);

const createOrder = db.transaction(order => {
    const result = insertOrder.run(order);

    order.items.forEach(item => {
        insertOrderItem.run({
            orderId: result.lastInsertRowid,
            productName: item.name,
            price: item.price,
            quantity: item.quantity,
            size: item.size,
            milk: item.milk,
            extraShot: item.extraShot
        });
    });

    return result.lastInsertRowid;
});

app.post("/api/orders", (req, res) => {
    const body = req.body || {};

    const customerName = asString(body.customerName);
    const phone = asString(body.phone);
    const fulfillment = asString(body.fulfillment) || "pickup";
    const address = asString(body.address);
    const items = Array.isArray(body.items) ? body.items : [];

    if (!customerName) {
        return res.status(400).json({ error: "Customer name is required." });
    }

    if (!isPhone(phone)) {
        return res.status(400).json({ error: "A valid phone number is required." });
    }

    if (!["pickup", "delivery"].includes(fulfillment)) {
        return res.status(400).json({ error: "Fulfillment must be pickup or delivery." });
    }

    if (fulfillment === "delivery" && !address) {
        return res.status(400).json({ error: "A delivery address is required." });
    }

    if (items.length === 0) {
        return res.status(400).json({ error: "Your cart is empty." });
    }

    const normalizedItems = [];

    for (const item of items) {
        const name = asString(item.name);
        const price = Number(item.price);
        const quantity = Number(item.quantity);

        if (!name || !Number.isFinite(price) || price < 0 || !Number.isInteger(quantity) || quantity < 1) {
            return res.status(400).json({ error: "One or more cart items are invalid." });
        }

        normalizedItems.push({
            name,
            price: Math.round(price),
            quantity,
            size: asString(item.customization && item.customization.size) || null,
            milk: asString(item.customization && item.customization.milk) || null,
            extraShot: item.customization && item.customization.extraShot ? 1 : 0
        });
    }

    const itemsTotal = normalizedItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const deliveryFee = fulfillment === "delivery" ? 40 : 0;
    const total = itemsTotal + deliveryFee;
    const orderNumber = `BB-${Date.now().toString().slice(-6)}`;

    createOrder({
        orderNumber,
        customerName,
        phone,
        fulfillment,
        address: fulfillment === "delivery" ? address : null,
        total,
        items: normalizedItems
    });

    res.status(201).json({ orderNumber, total, fulfillment, status: "received" });
});

app.get("/api/orders/:orderNumber", (req, res) => {
    const order = db.prepare("SELECT * FROM orders WHERE order_number = ?").get(req.params.orderNumber);

    if (!order) {
        return res.status(404).json({ error: "Order not found." });
    }

    order.items = db.prepare("SELECT * FROM order_items WHERE order_id = ?").all(order.id);

    res.json(order);
});

app.post("/api/reservations", (req, res) => {
    const body = req.body || {};

    const name = asString(body.name);
    const phone = asString(body.phone);
    const date = asString(body.date);
    const time = asString(body.time);
    const guests = Number(body.guests);

    if (!name) {
        return res.status(400).json({ error: "Name is required." });
    }

    if (!isPhone(phone)) {
        return res.status(400).json({ error: "A valid phone number is required." });
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
        return res.status(400).json({ error: "A valid date is required." });
    }

    if (!time) {
        return res.status(400).json({ error: "A reservation time is required." });
    }

    if (!Number.isInteger(guests) || guests < 1) {
        return res.status(400).json({ error: "Number of guests is invalid." });
    }

    const result = db.prepare(`
        INSERT INTO reservations (name, phone, date, time, guests)
        VALUES (?, ?, ?, ?, ?)
    `).run(name, phone, date, time, guests);

    res.status(201).json({ id: result.lastInsertRowid, name, date, time, guests });
});

app.post("/api/messages", (req, res) => {
    const body = req.body || {};

    const name = asString(body.name);
    const email = asString(body.email);
    const message = asString(body.message);

    if (!name || !message) {
        return res.status(400).json({ error: "Name and message are required." });
    }

    if (!isEmail(email)) {
        return res.status(400).json({ error: "A valid email address is required." });
    }

    const result = db.prepare(`
        INSERT INTO messages (name, email, message)
        VALUES (?, ?, ?)
    `).run(name, email, message);

    res.status(201).json({ id: result.lastInsertRowid });
});

app.use("/api", (req, res) => {
    res.status(404).json({ error: "Endpoint not found." });
});

app.listen(PORT, () => {
    console.log(`Brew & Bean server running at http://localhost:${PORT}`);
});
