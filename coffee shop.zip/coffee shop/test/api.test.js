const { test, before, after } = require("node:test");
const assert = require("node:assert/strict");
const { spawn } = require("node:child_process");
const net = require("node:net");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");

const root = path.join(__dirname, "..");
const dbPath = path.join(os.tmpdir(), `brew-bean-test-${process.pid}-${Date.now()}.db`);

let server;
let baseUrl;

function getFreePort() {
    return new Promise((resolve, reject) => {
        const probe = net.createServer();
        probe.on("error", reject);
        probe.listen(0, "127.0.0.1", () => {
            const { port } = probe.address();
            probe.close(() => resolve(port));
        });
    });
}

function runNode(args, env) {
    return new Promise((resolve, reject) => {
        const child = spawn(process.execPath, args, {
            cwd: root,
            env: { ...process.env, ...env },
            stdio: "ignore"
        });
        child.on("error", reject);
        child.on("exit", code => {
            if (code === 0) resolve();
            else reject(new Error(`node ${args.join(" ")} exited with code ${code}`));
        });
    });
}

async function waitForHealth(attempts = 100) {
    for (let i = 0; i < attempts; i += 1) {
        try {
            const res = await fetch(`${baseUrl}/api/health`);
            if (res.ok) return;
        } catch {
            // server not up yet
        }
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    throw new Error("Server did not become healthy in time.");
}

function post(pathname, body) {
    return fetch(`${baseUrl}${pathname}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
    });
}

before(async () => {
    await runNode(["server/seed.js"], { DB_PATH: dbPath });

    const port = await getFreePort();
    baseUrl = `http://127.0.0.1:${port}`;

    server = spawn(process.execPath, ["server/server.js"], {
        cwd: root,
        env: { ...process.env, DB_PATH: dbPath, PORT: String(port) },
        stdio: "ignore"
    });

    await waitForHealth();
});

after(async () => {
    if (server && server.exitCode === null) {
        await new Promise(resolve => {
            server.once("exit", resolve);
            server.kill();
        });
    }

    for (const suffix of ["", "-shm", "-wal"]) {
        fs.rmSync(`${dbPath}${suffix}`, { force: true, maxRetries: 10, retryDelay: 100 });
    }
});

test("GET /api/health reports ok", async () => {
    const res = await fetch(`${baseUrl}/api/health`);
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { ok: true });
});

test("GET /api/products returns the seeded menu", async () => {
    const res = await fetch(`${baseUrl}/api/products`);
    assert.equal(res.status, 200);
    const products = await res.json();
    assert.equal(products.length, 11);
    assert.ok(products.every(product => product.id && product.name && product.price));

    const mocha = products.find(product => product.name === "Mocha");
    assert.ok(mocha.image && !mocha.image.includes("1578314675249"));
    assert.ok(mocha.infoImage, "Mocha exposes an info image");
});

test("GET /api/products?category=cold filters by category", async () => {
    const res = await fetch(`${baseUrl}/api/products?category=cold`);
    const products = await res.json();
    assert.equal(products.length, 2);
    assert.ok(products.every(product => product.category === "cold"));
});

test("GET /api/products/:id returns one product and 404s when missing", async () => {
    const [first] = await (await fetch(`${baseUrl}/api/products`)).json();

    const found = await fetch(`${baseUrl}/api/products/${first.id}`);
    assert.equal(found.status, 200);
    assert.equal((await found.json()).name, first.name);

    const missing = await fetch(`${baseUrl}/api/products/999999`);
    assert.equal(missing.status, 404);
});

test("POST /api/orders creates an order and applies the delivery fee", async () => {
    const res = await post("/api/orders", {
        customerName: "Test User",
        phone: "9876543210",
        fulfillment: "delivery",
        address: "12 Main St",
        items: [{ name: "Latte", price: 180, quantity: 2 }]
    });

    assert.equal(res.status, 201);
    const order = await res.json();
    assert.match(order.orderNumber, /^BB-\d+$/);
    assert.equal(order.total, 400);
    assert.equal(order.fulfillment, "delivery");
    assert.equal(order.status, "received");

    const lookup = await fetch(`${baseUrl}/api/orders/${order.orderNumber}`);
    assert.equal(lookup.status, 200);
    const stored = await lookup.json();
    assert.equal(stored.items.length, 1);
    assert.equal(stored.items[0].product_name, "Latte");
    assert.equal(stored.items[0].quantity, 2);
});

test("POST /api/orders rejects invalid input with 400", async () => {
    const valid = { customerName: "Test User", phone: "9876543210", items: [{ name: "Latte", price: 180, quantity: 1 }] };
    const cases = [
        { ...valid, customerName: "" },
        { ...valid, phone: "123" },
        { ...valid, fulfillment: "teleport" },
        { ...valid, fulfillment: "delivery" },
        { ...valid, items: [] },
        { ...valid, items: [{ name: "Latte", price: 180, quantity: 0 }] }
    ];

    for (const body of cases) {
        const res = await post("/api/orders", body);
        assert.equal(res.status, 400, `expected 400 for ${JSON.stringify(body)}`);
        assert.ok((await res.json()).error);
    }
});

test("POST /api/reservations stores a booking", async () => {
    const res = await post("/api/reservations", {
        name: "Test User",
        phone: "9876543210",
        date: "2026-10-01",
        time: "18:30",
        guests: 4
    });

    assert.equal(res.status, 201);
    const booking = await res.json();
    assert.ok(booking.id);
    assert.equal(booking.guests, 4);
});

test("POST /api/messages stores a contact message", async () => {
    const res = await post("/api/messages", {
        name: "Test User",
        email: "test@example.com",
        message: "Hello there"
    });

    assert.equal(res.status, 201);
    assert.ok((await res.json()).id);
});

test("unknown API routes return a JSON 404", async () => {
    const res = await fetch(`${baseUrl}/api/does-not-exist`);
    assert.equal(res.status, 404);
    assert.deepEqual(await res.json(), { error: "Endpoint not found." });
});
