# Brew & Bean Coffee House

A modern coffee shop landing page and ordering website built with HTML, CSS, and JavaScript.

Brew & Bean is a responsive storefront designed to showcase a premium café brand with a polished layout, interactive menu browsing, customizable drinks, shopping cart functionality, reservation forms, and a contact section. It is suitable as a frontend portfolio project or as a base for a real coffee business website.

## Overview

This project demonstrates how a static website can provide a rich customer experience without a backend or framework. It includes:

- a responsive landing page
- navigation with mobile menu support
- menu filtering and search
- customizable drink selection
- cart and checkout interactions
- reservation and contact forms
- product gallery and review sections
- modern styling and animations

## Features

- Responsive coffee shop homepage
- Sticky navigation bar with mobile menu
- Hero section with brand messaging and call-to-action buttons
- About/story section
- Coffee brewing process section
- Searchable and filterable menu
- Category-based browsing
- Drink customization options, including:
  - size selection
  - milk type
  - extra espresso shot
- Shopping cart with quantity controls
- Browser localStorage support to persist cart data
- Pickup and delivery checkout flow
- Order confirmation with generated order number
- Reservation form for table bookings
- Contact form validation
- Countdown offer section
- Gallery lightbox interaction
- Customer review carousel
- Scroll reveal animations
- Back-to-top button
- Mobile, tablet, and desktop responsive layout

## Tech Stack

- HTML5
- CSS3
- JavaScript
- Font Awesome
- Google Fonts
- Unsplash for demo imagery

## Project Structure

```text
coffee-shop/
├── index.html
├── style.css
├── script.js
├── README.mdgt